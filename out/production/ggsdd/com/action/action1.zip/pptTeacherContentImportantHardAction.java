package com.action;

import com.bean.DdupPptteachercontentimportanthardEntity;
import com.service.pptTeacherContentImportantHardService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class pptTeacherContentImportantHardAction extends baseActionConfig8{
    private DdupPptteachercontentimportanthardEntity pptTeacherContentImportantHard;
    private com.service.pptTeacherContentImportantHardService pptTeacherContentImportantHardService;
    private String tno;
    private String pptNo;
    private int pptPageNum;


    public DdupPptteachercontentimportanthardEntity getPptTeacherContentImportantHard() {
        return pptTeacherContentImportantHard;
    }

    public void setPptTeacherContentImportantHard(DdupPptteachercontentimportanthardEntity pptTeacherContentImportantHard) {
        this.pptTeacherContentImportantHard = pptTeacherContentImportantHard;
    }

    public com.service.pptTeacherContentImportantHardService getPptTeacherContentImportantHardService() {
        return pptTeacherContentImportantHardService;
    }

    public void setPptTeacherContentImportantHardService(com.service.pptTeacherContentImportantHardService pptTeacherContentImportantHardService) {
        this.pptTeacherContentImportantHardService = pptTeacherContentImportantHardService;
    }

    public String getTno() {
        return tno;
    }

    public void setTno(String tno) {
        this.tno = tno;
    }

    public String getPptNo() {
        return pptNo;
    }

    public void setPptNo(String pptNo) {
        this.pptNo = pptNo;
    }

    public int getPptPageNum() {
        return pptPageNum;
    }

    public void setPptPageNum(int pptPageNum) {
        this.pptPageNum = pptPageNum;
    }

    public String findAllUser() {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try {
            List list = pptTeacherContentImportantHardService.findAll();
            if (list.size() != 0) {
                map.put("pptTeacherContentImportantHardList", list);
                status = "1";

            } else {
                status = "0";
            }
            map.put("status", status);
            return ajax(map);
        } catch (Exception e) {
            status="-1";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
    public String findById(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try{
            List list=pptTeacherContentImportantHardService.findById(pptNo);
            if(list.size()!=0){
                pptTeacherContentImportantHard=(DdupPptteachercontentimportanthardEntity) list.get(0);
                map.put("pptTeacherContentImportantHard",pptTeacherContentImportantHard);
                status="1";
            }
            else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }

    }

    public String findByHql() {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try {
            List list = pptTeacherContentImportantHardService.findByHql(tno, pptNo, pptPageNum);
            if (list.size() != 0) {
                pptTeacherContentImportantHard = (DdupPptteachercontentimportanthardEntity) list.get(0);
                map.put("pptTeacherContentHard", pptTeacherContentImportantHard);
                status = "1";
            } else {
                status = "0";
            }
            map.put("status", status);
            return ajax(map);
        } catch (Exception e) {
            status = "0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }


    public String add(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try{
            pptTeacherContentImportantHard=new DdupPptteachercontentimportanthardEntity();
            pptTeacherContentImportantHard.setDdupTno(tno);
            System.out.println(tno);
            pptTeacherContentImportantHard.setDdupPptNo(pptNo);
            pptTeacherContentImportantHard.setDdupPptPageNum(pptPageNum);
            if(pptTeacherContentImportantHardService.add(pptTeacherContentImportantHard)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="-1";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }

    public String update(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try{
            pptTeacherContentImportantHard=new DdupPptteachercontentimportanthardEntity();
            pptTeacherContentImportantHard.setDdupTno(tno);
            System.out.println(tno);
            pptTeacherContentImportantHard.setDdupPptNo(pptNo);
            pptTeacherContentImportantHard.setDdupPptPageNum(pptPageNum);
            if(pptTeacherContentImportantHardService.updateInfo(pptTeacherContentImportantHard)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
    public String deleteById() {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try {

            if (pptTeacherContentImportantHardService.deleteByHql(tno,pptNo,pptPageNum)) {
                status = "1";
            } else {
                status = "0";
            }
            map.put("status", status);
            return ajax(map);
        } catch (Exception e) {
            status = "0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
}
