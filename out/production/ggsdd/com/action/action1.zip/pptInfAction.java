package com.action;

public class pptInfAction {
}
