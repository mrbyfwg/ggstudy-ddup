package com.action;

import com.bean.DdupPptteachercontenthardEntity;
import com.service.pptTeacherContentHardService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class pptTeacherContentHardAction extends baseActionConfig8 {
    private DdupPptteachercontenthardEntity pptTeacherContentHard;
    private pptTeacherContentHardService pptTeacherContentHardService;
    private String tno;
    private String pptNo;
    private int pptPageNum;


    public DdupPptteachercontenthardEntity getPptTeacherContentHard() {
        return pptTeacherContentHard;
    }

    public void setPptTeacherContentHard(DdupPptteachercontenthardEntity pptTeacherContentHard) {
        this.pptTeacherContentHard = pptTeacherContentHard;
    }

    public com.service.pptTeacherContentHardService getPptTeacherContentHardService() {
        return pptTeacherContentHardService;
    }

    public void setPptTeacherContentHardService(com.service.pptTeacherContentHardService pptTeacherContentHardService) {
        this.pptTeacherContentHardService = pptTeacherContentHardService;
    }

    public String getTno() {
        return tno;
    }

    public void setTno(String tno) {
        this.tno = tno;
    }

    public String getPptNo() {
        return pptNo;
    }

    public void setPptNo(String pptNo) {
        this.pptNo = pptNo;
    }

    public int getPptPageNum() {
        return pptPageNum;
    }

    public void setPptPageNum(int pptPageNum) {
        this.pptPageNum = pptPageNum;
    }

    public String findAllUser() {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try {
            List list = pptTeacherContentHardService.findAll();
            if (list.size() != 0) {
                map.put("pptTeacherContentHardList", list);
                status = "1";

            } else {
                status = "0";
            }
            map.put("status", status);
            return ajax(map);
        } catch (Exception e) {
            status="-1";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
    public String findById(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try{
            List list=pptTeacherContentHardService.findById(pptNo);
            if(list.size()!=0){
                //pptTeacherContentHard=(DdupPptteachercontenthardEntity) list.get(0);
                map.put("pptTeacherContentHardList",list);
                status="1";
            }
            else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }

    }

    public String findByHql() {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try {
            List list = pptTeacherContentHardService.findByHql(tno, pptNo, pptPageNum);
            if (list.size() != 0) {
                pptTeacherContentHard = (DdupPptteachercontenthardEntity) list.get(0);
                map.put("pptTeacherContentHard", pptTeacherContentHard);
                status = "1";
            } else {
                status = "0";
            }
            map.put("status", status);
            return ajax(map);
        } catch (Exception e) {
            status = "0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }

    public String add(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try{
            pptTeacherContentHard=new DdupPptteachercontenthardEntity();
            pptTeacherContentHard.setDdupTno(tno);
            System.out.println(tno);
            pptTeacherContentHard.setDdupPptNo(pptNo);
            pptTeacherContentHard.setDdupPptPageNum(pptPageNum);
            if(pptTeacherContentHardService.add(pptTeacherContentHard)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="-1";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }

    public String update(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try{
            pptTeacherContentHard=new DdupPptteachercontenthardEntity();
            pptTeacherContentHard.setDdupTno(tno);
            System.out.println(tno);
            pptTeacherContentHard.setDdupPptNo(pptNo);
            pptTeacherContentHard.setDdupPptPageNum(pptPageNum);
            if(pptTeacherContentHardService.updateInfo(pptTeacherContentHard)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
    public String deleteById(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try{
            if(pptTeacherContentHardService.deleteByHql(tno,pptNo,pptPageNum)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }

    }}
