package com.action;

import com.bean.DdupPptstudentcontentEntity;
import com.service.pptStudentContentService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class pptStudentContentAction extends baseActionConfig6{
    private DdupPptstudentcontentEntity pptStudentContentEntity;
    private pptStudentContentService pptStudentContentEntityService;
    private String sno;
    private String pptNo;
    private int pptPageNum;

    public DdupPptstudentcontentEntity getPptStudentContentEntity() {
        return pptStudentContentEntity;
    }

    public void setPptStudentContentEntity(DdupPptstudentcontentEntity pptStudentContentEntity) {
        this.pptStudentContentEntity = pptStudentContentEntity;
    }

    public com.service.pptStudentContentService getPptStudentContentEntityService() {
        return pptStudentContentEntityService;
    }

    public void setPptStudentContentEntityService(com.service.pptStudentContentService pptStudentContentEntityService) {
        this.pptStudentContentEntityService = pptStudentContentEntityService;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public String getPptNo() {
        return pptNo;
    }

    public void setPptNo(String pptNo) {
        this.pptNo = pptNo;
    }

    public int getPptPageNum() {
        return pptPageNum;
    }

    public void setPptPageNum(int pptPageNum) {
        this.pptPageNum = pptPageNum;
    }

    public String findAllUser() {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try {
            List list = pptStudentContentEntityService.findAll();
            if (list.size() != 0) {
                map.put("pptStudentContentList", list);
                status = "1";
            } else {
                status = "0";
            }
            map.put("status", status);
            return ajax(map);
        } catch (Exception e) {
            status="-1";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
    public String findById(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try{
            List list=pptStudentContentEntityService.findById(pptNo);
            if(list.size()!=0){
                pptStudentContentEntity=(DdupPptstudentcontentEntity) list.get(0);
                map.put("pptStudentContentEntity",pptStudentContentEntity);
                status="1";
            }
            else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }

    }

    public String add(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try{
            pptStudentContentEntity  =new DdupPptstudentcontentEntity();
            pptStudentContentEntity.setDdupSno(sno);
            System.out.println(sno);
            pptStudentContentEntity.setDdupPptNo(pptNo);
            pptStudentContentEntity.setDdupPptPageNum(pptPageNum);
            if(pptStudentContentEntityService.add(pptStudentContentEntity)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="-1";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }

    public String update(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;
        try{
            pptStudentContentEntity=new DdupPptstudentcontentEntity();
            pptStudentContentEntity.setDdupSno(sno);
            System.out.println(sno);
            pptStudentContentEntity.setDdupPptNo(pptNo);
            pptStudentContentEntity.setDdupPptPageNum(pptPageNum);
            if(pptStudentContentEntityService.updateInfo(pptStudentContentEntity)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }
    }
    public String deleteById(){
        Map<String, Object> map = new HashMap<String, Object>();
        String status = null;

        try{

            if(pptStudentContentEntityService.deleteByHql(sno,pptNo,pptPageNum)){
                status="1";
            }else{
                status="0";
            }
            map.put("status", status);
            return ajax(map);
        }catch (Exception e) {
            status="0";
            map.put("status", status);
            e.printStackTrace();
            return ajax(map);
        }

    }
}
